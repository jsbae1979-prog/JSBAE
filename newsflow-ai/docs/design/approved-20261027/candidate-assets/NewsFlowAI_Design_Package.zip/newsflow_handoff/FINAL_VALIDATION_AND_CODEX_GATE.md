# NewsFlow AI — 디자인 인수 검증 및 Codex 실행 전 게이트

기준일: 2026-10-27 KST  |  GitHub PR #35 기준 HEAD: `75626f74cc1bfe750d24132e44019bcda478247b` (최종 작업 시 재조회)

## 검증 결과

- PNG 11개: 파일 존재 / SHA-256 / 이미지 해상도 일치 **PASS**.
- ZIP 내부 구성: 파일 목록과 기준서 존재 **PASS**.
- 사용자 승인 버전과 원본 PNG의 육안 1:1 식별: **NOT VERIFIED**. 특히 뉴스 쇼츠 2차는 원본 식별 추가 대조 필요.
- 대시보드·콘텐츠 제작 홈: 현재 React 디자인 보존 대상. PNG 대체 금지.
- UI 이미지의 수치, 계정, 연결 성공, 게시 성공, 모델, 버튼: 예시. 구현된 기능·운영 실적 증거 아님.
- 실제 Windows DPI/운영 기능/게시/유료 API: **NOT EXECUTED**.

## 화면별 승인 버전 및 PNG 파일

| 화면 | 승인 버전 | 파일 | 판정 |
|---|---|---|---|
| news_shorts_v2 | 뉴스 쇼츠 2차 | `approved_mockups/news_shorts_v2.png` | 원본 식별 대조 필요 |
| character_shorts_v4 | 캐릭터 쇼츠 4차 간편 | `approved_mockups/character_shorts_v4.png` | 후보 식별, 사용자 승인 이미지와 최종 대조 필요 |
| standalone_image_v2 | 독립 AI 이미지 2차 | `approved_mockups/standalone_image_v2.png` | 후보 식별, 사용자 승인 이미지와 최종 대조 필요 |
| news_image_v2 | 뉴스 기반 이미지 2차 | `approved_mockups/news_image_v2.png` | 후보 식별, 사용자 승인 이미지와 최종 대조 필요 |
| top3_feed_v3 | TOP 3 자동 피드 3차 | `approved_mockups/top3_feed_v3.png` | 후보 식별, 사용자 승인 이미지와 최종 대조 필요 |
| news_studio_v2 | 뉴스 스튜디오 2차 | `approved_mockups/news_studio_v2.png` | 후보 식별, 사용자 승인 이미지와 최종 대조 필요 |
| automation_v1 | 자동화 센터 1차 | `approved_mockups/automation_v1.png` | 후보 식별, 사용자 승인 이미지와 최종 대조 필요 |
| library_v2 | 라이브러리 2차 | `approved_mockups/library_v2.png` | 후보 식별, 사용자 승인 이미지와 최종 대조 필요 |
| publishing_v4 | 게시 스튜디오 4차 | `approved_mockups/publishing_v4.png` | 후보 식별, 사용자 승인 이미지와 최종 대조 필요 |
| analytics_v4_option2 | 성과·비용 4차 두 번째 | `approved_mockups/analytics_v4_option2.png` | 후보 식별, 사용자 승인 이미지와 최종 대조 필요 |
| settings_v2 | 설정·관리 2차 | `approved_mockups/settings_v2.png` | 후보 식별, 사용자 승인 이미지와 최종 대조 필요 |

## 기능·보안 매핑 게이트

1. 최신 HEAD에서 실제 메뉴/React JSX/CSS와 Python 서비스·API 계약을 다시 확인한다. 구현되지 않은 버튼은 신규 기능으로 만들지 않는다.
2. 뉴스/캐릭터/이미지 생성: 기존 데이터, 대본, 장면, 비용 견적 및 승인 계약을 보존한다.
3. TOP 3: 3개 기사별 독립 성공·실패·결과 불명 상태, 유료 승인 전 차단, 자동 재시도 금지.
4. 자동화: 예약 저장과 활성화 구분, 미확인 결과 재실행 금지.
5. 게시: Instagram 다중 계정 및 YouTube/TikTok/Facebook을 구분한다. TikTok/Facebook 실계정 전송 차단 상태를 유지한다. 게시 검토·권한·최종 승인 전 실행 금지.
6. 성과: 실측과 합성 구분, 계정별 지표 보존, 미수집을 0으로 표시하지 않음. 비용은 청구액/추정액/미확인 분리.
7. 설정: API 키·DPAPI·계정·Windows 자동 시작 상태를 실제 조회 결과만 표시. 비밀값 노출 금지.
8. 홈과 콘텐츠 제작 홈: JSX/CSS/공통 스타일의 간접 변화까지 시각 회귀 0건 확인.

## 검증 완료 전 금지

- PR #35/main 수정·병합, 운영 앱 재시작, 운영 데이터/계정/키 수정, 실계정 OAuth·유료 API·SNS 게시.
- PNG 속 가상 성공 수치/계정명을 실제 값으로 사용.
- 승인 시안 원본 식별이 미확정된 화면을 임의 추정하여 구현.

## Codex 구현 절차 제안 (아직 전송하지 않음)

- 지정 격리 브랜치와 최신 HEAD 확인 후 기존 사용자 작업 보존.
- 승인 이미지 식별을 먼저 검증하고, 불확실한 화면은 사용자에게 확인 요청.
- 컴포넌트별 기능 대응표와 변경 파일 목록 작성 후, 디자인만 최소 변경.
- 1920×1080, 1366×768 비교 캡처 및 관련 기능 회귀 실행. Windows DPI는 실제 테스트 전 NOT VERIFIED.
- 디자인/기능/보안/Windows 판정 별도 제출. 운영 적용·병합 없이 결과 보고.
